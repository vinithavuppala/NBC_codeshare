package apiTest;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.FileEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.testng.annotations.Test;

public class ApiTest {
	
	String url="https://api.nasa.gov/planetary/sounds";
@Test
public void posiveTest() throws ClientProtocolException, IOException{

	
    
    
	    
    
  
    
    
    
    int timeout =2000;
    RequestConfig config = RequestConfig.custom()
      .setConnectTimeout(timeout * 1000)
      .setConnectionRequestTimeout(timeout * 1000)
      .setSocketTimeout(timeout * 1000).build();
    
    CloseableHttpClient httpclient = 
    		  HttpClientBuilder.create().setDefaultRequestConfig(config).build();
   // CloseableHttpClient httpclient = HttpClients.createDefault();
    
    try {
          
        HttpGet httppost = new HttpGet(url);
        
        

        System.out.println("executing request " + httppost.getRequestLine());
        CloseableHttpResponse response = httpclient.execute(httppost);
        
        try {
          
       
            HttpEntity resEntity = response.getEntity();
                      
            
            
         
            if (response.getStatusLine().getStatusCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + response.getStatusLine().getStatusCode());
			}
            
            
          BufferedReader in = new BufferedReader(new InputStreamReader(resEntity.getContent()));
          String inputLine;
          StringBuilder out = new StringBuilder();
          
		while ((inputLine = in.readLine()) != null) {
		
             System.out.println(inputLine);
              out.append(inputLine); 
		}
		
		
	
	
	
        }finally {
        	
            response.close();
        }
    } finally {
        httpclient.close();
    }
    }



@Test
public void negtiveTest() throws ClientProtocolException, IOException{

	
    
    
	    
    
  
    
    
    
    int timeout =2000;
    RequestConfig config = RequestConfig.custom()
      .setConnectTimeout(timeout * 1000)
      .setConnectionRequestTimeout(timeout * 1000)
      .setSocketTimeout(timeout * 1000).build();
    
    CloseableHttpClient httpclient = 
    		  HttpClientBuilder.create().setDefaultRequestConfig(config).build();
   // CloseableHttpClient httpclient = HttpClients.createDefault();
    
    try {
          
        HttpGet httppost = new HttpGet(url);
        
        

        System.out.println("executing request " + httppost.getRequestLine());
        CloseableHttpResponse response = httpclient.execute(httppost);
        
        try {
          
       
            HttpEntity resEntity = response.getEntity();
         
            
            if (response.getStatusLine().getStatusCode() != 403) {
				throw new RuntimeException("Failed : HTTP error code : " + response.getStatusLine().getStatusCode());
			}
            
            
          BufferedReader in = new BufferedReader(new InputStreamReader(resEntity.getContent()));
          String inputLine;
          StringBuilder out = new StringBuilder();
          
		while ((inputLine = in.readLine()) != null) {
		
             System.out.println(inputLine);
              out.append(inputLine); 
		}
		
		
	
	
	
        }finally {
        	
            response.close();
        }
    } finally {
        httpclient.close();
    }
    }



}
